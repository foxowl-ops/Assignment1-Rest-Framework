from django.contrib import admin
from quotes.models import Quotes, Language

admin.site.register(Quotes)
admin.site.register(Language)

# Register your models here.
